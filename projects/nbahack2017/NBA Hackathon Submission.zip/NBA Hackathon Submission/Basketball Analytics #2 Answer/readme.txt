Hello NBA Hackathon Judges,

Our names are Francis Lin and Michael Wong. We are submitting this zip file for the 2nd question
of the 2017 NBA Hackathon.

This zip file includes the following documents:
1. Basketball Analytics #2.pdf				Writeup of our Excel code
2. Analytics_Attachment_Francis_Michael_Final.xlsm	Contains original data plus Excel Macro
3. NBA_Clinch_Dates.csv					Contains dates filled in
4. Excel_Macro_code.txt					A .txt version of the Excel Macro

To run the Excel macro:
1. Open Excel file
2. Enable macros
3. On Windows, press Alt+F11. On Mac, press Fn+Alt+F11.
4. Run Sub GenerateDates(). This may cause Excel to look like it will freeze, but it will generate the dates after a few seconds.

Thank you for taking the time to review our application! We hope you have a wonderful day.

Best,
Francis & Michael